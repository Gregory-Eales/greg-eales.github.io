---
layout: tags
tag: cool
permalink: /tag/cool/
---
