---
layout: about
title: About
permalink: /about/
---

This is a Jekyll theme called Minimaless. It's forked from the popular theme Minima. It's like Minima, but there's less noise.

This is a good theme for portfolios and blogs. It's not a good theme for meeting hot singles in your area. You can see a production example of this site on the author's [blog](http://www.brettgardiner.net). Check out the source code for this Jekyll theme:

[brettinternet<i class="fa fa-external-link"></i>](https://github.com/brettinternet){:target="_blank"} /
[minimaless<i class="fa fa-external-link"></i>](https://github.com/brettinternet/minimaless){:target="_blank"}.

<br/>
Visit this site's [blog]({{site.baseurl}}) or [contact]({{site.baseurl}}/contact/) page.
