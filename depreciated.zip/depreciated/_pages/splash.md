---
layout: splash
title: Splash
permalink: /splash/
---

I'm [brettinternet](http://www.brettgardiner.net/about/).

Read my tech [blog](http://www.brettgardiner.net) or find me on social media.
